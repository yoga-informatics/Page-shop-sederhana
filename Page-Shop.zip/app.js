const express = require("express");
const mysql = require("mysql2");
const bodyParser = require("body-parser");
const app = express();

app.set("view engine", "ejs");
app.use(express.static("public"));
app.use(bodyParser.urlencoded({ extended: false }));

const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "shopdb"
});

// Home - Produk
app.get("/", (req, res) => {
  db.query("SELECT * FROM produk", (err, produk) => {
    res.render("index", { produk });
  });
});

// Form Pembelian
app.get("/pembelian", (req, res) => {
  db.query("SELECT * FROM produk", (err, produk) => {
    res.render("pembelian", { produk });
  });
});

// Proses Pembelian
app.post("/pembelian", (req, res) => {
  const { produk_id, qty } = req.body;

  db.query("SELECT harga FROM produk WHERE id=?", [produk_id], (err, rows) => {
    const harga = rows[0].harga;
    const total = harga * qty;

    db.query(
      "INSERT INTO pembelian (produk_id, qty, total) VALUES (?,?,?)",
      [produk_id, qty, total],
      () => {
        db.query(
          "UPDATE stock SET qty = qty - ? WHERE produk_id=?",
          [qty, produk_id],
          () => res.redirect("/pembelian/list")
        );
      }
    );
  });
});

// List Pembelian
app.get("/pembelian/list", (req, res) => {
  db.query(
    `SELECT p.id, produk.nama, p.qty, p.total, p.status
     FROM pembelian p JOIN produk ON p.produk_id = produk.id`,
    (err, pembelian) => {
      res.render("pembelian_list", { pembelian });
    }
  );
});

// Cancel Pembelian
app.get("/pembelian/cancel/:id", (req, res) => {
  const id = req.params.id;

  db.query(
    "UPDATE pembelian SET status='cancelled' WHERE id=?",
    [id],
    () => res.redirect("/pembelian/list")
  );
});

app.listen(3000, () => console.log("Server berjalan di http://localhost:3000"));
